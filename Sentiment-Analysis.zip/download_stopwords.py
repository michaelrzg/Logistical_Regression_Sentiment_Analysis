# if you have never run nltk before, this script can help you avoid errors when using stopwords

import nltk
import ssl

try:
    _create_unverified_https_context = ssl._create_unverified_context
except AttributeError:
    pass
else:
    ssl._create_default_https_context = _create_unverified_https_context

nltk.download('stopwords')
nltk.download('opinion_lexicon')
nltk.download('punkt_tab')